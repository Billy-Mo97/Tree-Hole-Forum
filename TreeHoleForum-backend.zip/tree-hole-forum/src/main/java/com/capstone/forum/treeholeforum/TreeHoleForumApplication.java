package com.capstone.forum.treeholeforum;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TreeHoleForumApplication {

	public static void main(String[] args) {
		SpringApplication.run(TreeHoleForumApplication.class, args);
	}

}
