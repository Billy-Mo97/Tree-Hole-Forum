package com.capstone.forum.treeholeforum;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TreeHoleForumApplicationTests {

	@Test
	void contextLoads() {
	}

}
