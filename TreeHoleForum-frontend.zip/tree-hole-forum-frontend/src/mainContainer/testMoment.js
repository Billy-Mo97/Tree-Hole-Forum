export const momentJson =
    [
        {
            id: "1",
            createdUser: "zehuapeng",
            topic: "Daily Lives",
            createdTime: "2020-11-30",
            contents:"We supply a series of design principles, practical patterns and high quality design\n" +
                "resources (Sketch and Axure), to help people create their product prototypes beautifully\n" +
                "and efficiently.",
            comments: [
                {
                    createdUser: "zehuapeng",
                    createdTime: "2020-11-30",
                    contents:"I like your moment"
                },
                {
                    createdUser: "zehuapeng",
                    createdTime: "2020-11-30",
                    contents:"I like your moment"
                },
                {
                    createdUser: "zehuapeng",
                    createdTime: "2020-11-30",
                    contents:"I like your moment"
                },
                {
                    createdUser: "zehuapeng",
                    createdTime: "2020-11-30",
                    contents:"I like your moment"
                }
            ]
        },
        {
            id: "2",
            createdUser: "zehuapeng",
            topic: "Covid-19",
            createdTime: "2020-11-30",
            contents:"We supply a series of design principles, practical patterns and high quality design\n" +
                "resources (Sketch and Axure), to help people create their product prototypes beautifully\n" +
                "and efficiently.",
            comments: [
                {
                    createdUser: "zehuapeng",
                    createdTime: "2020-11-30",
                    contents:"I like your moment"
                },
                {
                    createdUser: "zehuapeng",
                    createdTime: "2020-11-30",
                    contents:"I like your moment"
                },
                {
                    createdUser: "zehuapeng",
                    createdTime: "2020-11-30",
                    contents:"I like your moment"
                },
                {
                    createdUser: "zehuapeng",
                    createdTime: "2020-11-30",
                    contents:"I like your moment"
                }
            ]
        }
    ]
